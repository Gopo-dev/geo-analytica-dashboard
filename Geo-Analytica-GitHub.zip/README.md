
# Geo-Analytica Dashboard

A real-time political, corporate, and social media analytics dashboard built with Streamlit.

## Run Locally
1. Clone this repo
2. Run: `pip install -r requirements.txt`
3. Run: `streamlit run app.py`
